#pragma once

#include "display/lcd_display.h"
#include "device_state.h"

#include <esp_timer.h>
#include <memory>
#include <string>

class AuroraMax35Display : public SpiLcdDisplay {
public:
    AuroraMax35Display(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_handle_t panel,
                       int width, int height, int offset_x, int offset_y,
                       bool mirror_x, bool mirror_y, bool swap_xy);
    ~AuroraMax35Display() override;

    void SetStatus(const char* status) override;
    void ShowNotification(const char* notification, int duration_ms = 3000) override;
    void SetEmotion(const char* emotion) override;
    void SetChatMessage(const char* role, const char* content) override;
    void SetPreviewImage(std::unique_ptr<LvglImage> image) override;
    void UpdateStatusBar(bool update_all = false) override;

private:
    enum class Page {
        Home,
        Chat,
        Camera,
    };

    void BuildAuroraUi();
    void HideFactoryUi();
    void ShowPageInternal(Page page);
    void UpdateHomeClockInternal();
    void UpdateHomeStateInternal(DeviceState state);
    void UpdateChatStateInternal(DeviceState state);
    void ResetConversationInternal();
    void SetAssistantTextInternal(const std::string& text);
    void StopReadableScrollInternal();
    int64_t StartReadableScrollInternal(int delay_ms = 1700, int ms_per_pixel = 82);
    void ScheduleReadableScrollInternal();
    void FinishCameraPreviewInternal();
    void CopyFactoryStatusIconsInternal();
    void SetNotificationVisibleInternal(bool visible);

    static bool LooksLikeClock(const char* text);
    static bool IsConversing(DeviceState state);
    static const char* StateText(DeviceState state);
    static uint32_t StateColor(DeviceState state);
    static const char* WeekdayText(int weekday);
    static void NotificationTimerCallback(void* arg);

    Page page_ = Page::Home;
    Page page_before_camera_ = Page::Home;
    DeviceState last_state_ = kDeviceStateUnknown;

    lv_obj_t* aurora_root_ = nullptr;
    lv_obj_t* home_root_ = nullptr;
    lv_obj_t* home_brand_ = nullptr;
    lv_obj_t* home_clock_ = nullptr;
    lv_obj_t* home_date_ = nullptr;
    lv_obj_t* home_core_outer_ = nullptr;
    lv_obj_t* home_core_inner_ = nullptr;
    lv_obj_t* home_core_icon_ = nullptr;
    lv_obj_t* home_state_ = nullptr;
    lv_obj_t* home_subtitle_ = nullptr;
    lv_obj_t* home_network_ = nullptr;
    lv_obj_t* home_battery_ = nullptr;
    lv_obj_t* home_mute_ = nullptr;
    lv_obj_t* home_hint_ = nullptr;

    lv_obj_t* chat_root_ = nullptr;
    lv_obj_t* chat_state_dot_ = nullptr;
    lv_obj_t* chat_state_ = nullptr;
    lv_obj_t* chat_user_text_ = nullptr;
    lv_obj_t* chat_answer_box_ = nullptr;
    lv_obj_t* chat_answer_ = nullptr;
    lv_obj_t* chat_footer_ = nullptr;

    lv_obj_t* camera_root_ = nullptr;
    lv_obj_t* camera_image_ = nullptr;
    lv_obj_t* camera_status_ = nullptr;
    std::unique_ptr<LvglImage> aurora_preview_cache_;

    lv_obj_t* notification_panel_ = nullptr;
    lv_obj_t* notification_text_ = nullptr;
    esp_timer_handle_t aurora_notification_timer_ = nullptr;

    std::string last_status_;
    std::string last_system_message_;
    std::string user_text_;
    std::string assistant_text_;
    std::string last_assistant_fragment_;

    bool conversation_active_ = false;
    bool waiting_for_answer_ = false;
    bool scroll_pending_ = false;
    int64_t scroll_due_us_ = 0;
    int64_t scroll_finish_us_ = 0;
    int64_t return_home_us_ = 0;
};
